export default {
  primary: "rgb(38, 80, 120)",
  accent: "rgb(35, 129, 172)",
  white: "#FFFFFF",
  black: "#000000",
  buttonBg: "hsl(210, 83%, 79%)",
};
