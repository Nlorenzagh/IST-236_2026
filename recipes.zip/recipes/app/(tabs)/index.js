import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { useState } from "react";
import AddRecipeScreen from "../../screens/addrecipescreen";
import HomeScreen from "../../screens/index";
import RecipesScreen from "../../screens/recipesscreen";

const Stack = createNativeStackNavigator();
export default function App() {
  const [recipes, setRecipes] = useState([]);

  const addRecipe = (title, text) => {
    setRecipes((prevRecipes) => [
      ...prevRecipes,
      { id: Math.random().toString(), title, text },
    ]);
  };

  const deleteRecipe = (id) => {
    setRecipes((prevRecipes) =>
      prevRecipes.filter((recipe) => recipe.id !== id),
    );
  };

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Home">
        {(props) => <HomeScreen {...props} />}
      </Stack.Screen>

      <Stack.Screen name="Recipes">
        {(props) => (
          <RecipesScreen
            {...props}
            recipes={recipes}
            deleteRecipe={deleteRecipe}
          />
        )}
      </Stack.Screen>

      <Stack.Screen name="AddRecipe">
        {(props) => <AddRecipeScreen {...props} addRecipe={addRecipe} />}
      </Stack.Screen>
    </Stack.Navigator>
  );
}
