import { Button, StyleSheet, Text, View } from "react-native";

export default function RecipeItem({ item, onView, onDelete }) {
  return (
    <View style={styles.row}>
      <Text>{item.title}</Text>
      <View style={styles.buttons}>
        <Button title="View" onPress={onView} />
        <Button title="Delete" onPress={onDelete} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: "center",
    justifyContent: "center",
    marginVertical: 10,
    alignItems: "center",
  },
  buttons: {
    flexDirection: "row",
    marginLeft: 8,
  },
});
