import { Button, Modal, StyleSheet, Text, View } from "react-native";

export default function RecipeModal({ visible, recipe, onClose }) {
  if (!recipe) return null;

  return (
    <Modal visible={visible} animationType="slide">
      <View style={styles.container}>
        <Text style={styles.title}>{recipe.title}</Text>
        <Text>{recipe.text}</Text>
        <Button title="Back to Recipes" onPress={onClose} />
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#466381",
    justifyContent: "center",
    padding: 20,
  },
  card: {
    backgroundColor: "#4459b5",
    padding: 20,
    borderRadius: 12,
    elevation: 5,
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 10,
    textAlign: "center",
  },
  text: {
    fontSize: 16,
    marginBottom: 20,
    textAlign: "center",
  },
  buttonWrapper: {
    marginTop: 10,
  },
});
