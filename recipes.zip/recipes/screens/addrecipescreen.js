import { useState } from "react";
import { Button, StyleSheet, TextInput, View } from "react-native";

export default function AddRecipeScreen({ navigation, addRecipe }) {
  const [title, setTitle] = useState("");
  const [text, setText] = useState("");

  const saveHandler = () => {
    addRecipe(title, text);
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <TextInput
        placeholder="Recipe Title"
        style={styles.input}
        value={title}
        onChangeText={setTitle}
      />

      <TextInput
        placeholder="Recipe Instructions"
        style={[styles.input, { height: 100 }]}
        multiline
        value={text}
        onChangeText={setText}
      />

      <Button title="Save" onPress={saveHandler} />
      <Button title="Cancel" onPress={() => navigation.goBack()} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1f4b76",
    padding: 20,
  },
  input: {
    backgroundColor: "#1d799b",
    borderRadius: 8,
    padding: 12,
    marginBottom: 15,
    borderWidth: 1,
  },
  buttonContainer: {
    marginVertical: 8,
  },
});
