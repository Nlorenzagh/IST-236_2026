import { Button, Image, StyleSheet, Text, View } from "react-native";

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Recipe App</Text>
      <Text style={styles.title}>
        Click on the View Recipe button to get things started!
      </Text>

      <Image
        source={require("../assets/images/recipes.jpg")}
        style={styles.image}
      />

      <Button
        title="View Recipes"
        onPress={() => navigation.navigate("Recipes")}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#315a84",
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    marginBottom: 20,
    color: "#333",
  },
  image: {
    width: 250,
    height: 150,
    marginBottom: 20,
    borderRadius: 10,
  },
});
