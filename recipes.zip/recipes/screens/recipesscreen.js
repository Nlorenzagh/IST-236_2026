import { useState } from "react";
import { Button, FlatList, StyleSheet, View } from "react-native";
import RecipeItem from "../components/recipeitem";
import RecipeModal from "../components/recipemodal";

export default function RecipesScreen({ navigation, recipes, deleteRecipe }) {
  const [selectedRecipe, setSelectedRecipe] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);

  const openModal = (recipe) => {
    setSelectedRecipe(recipe);
    setModalVisible(true);
  };

  return (
    <View style={styles.container}>
      <View style={styles.centerButton}>
        <Button
          title="Add Recipe"
          onPress={() => navigation.navigate("AddRecipe")}
        />
      </View>

      <FlatList
        data={recipes}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <RecipeItem
            item={item}
            onView={() => openModal(item)}
            onDelete={() => deleteRecipe(item.id)}
          />
        )}
      />

      <View style={styles.centerButton}>
        <Button
          title="Back to Home"
          onPress={() => navigation.navigate("Home")}
        />
      </View>

      <RecipeModal
        visible={modalVisible}
        recipe={selectedRecipe}
        onClose={() => setModalVisible(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#466381",
    padding: 20,
  },
  centerButton: {
    alignItems: "center",
    marginVertical: 10,
  },
});
